window.LEADERBOARD_CONFIG = {
  supabaseUrl: "https://qhzggsmwfyzxziqrhqto.supabase.co",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFoemdnc213Znl6eHppcXJocXRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2OTU4MzUsImV4cCI6MjA4NjI3MTgzNX0.nfKWcyxiRff5Jn6hRZDPnn7ME6L2Z3YShEMmtV7tgfs",
  table: "leaderboard_entries",
};
